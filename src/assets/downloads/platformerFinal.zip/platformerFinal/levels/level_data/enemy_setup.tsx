<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="enemy_setup" tilewidth="16" tileheight="16" tilecount="2" columns="2">
 <image source="../../graphics/enemy_setup.png" width="32" height="16"/>
</tileset>
