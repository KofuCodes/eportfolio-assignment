<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="orbs" tilewidth="6" tileheight="6" tilecount="2" columns="2">
 <image source="../../graphics/orbs.png" width="12" height="6"/>
</tileset>
