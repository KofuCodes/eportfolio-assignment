<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="big_tree" tilewidth="16" tileheight="16" tilecount="63" columns="7">
 <image source="../../graphics/big_tree.png" width="112" height="144"/>
</tileset>
